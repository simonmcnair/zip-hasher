import XMLSerialize

data = {
    'hey' : "123asd",
    'there' : "he3jahdad",
    'what' : [1, 2, 3, 4],
    'is' : {
        'name' : "Deba"
    } 
}

# a = XMLSerialize.Py2XML()
# a.parse(data)

# print a
