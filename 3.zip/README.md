Requirements :
  `python2.7` and lxml library installed

Instructions : 
  1. Install `lxml` library from `pip` or do a `pip install -r requirements.txt`
  2. Set correct configurations on `config.txt`, kindly check if the temp directory has necessary read/write permissions, set the correct path for the xml file, preferrably give the full path.
  2. run `python main.py path/to/zipfile.zip`
